# Public

**This directory is not required, you can delete it if you don't want to use it.**

This directory stores your static resources.

Sometimes you may need to provide static assets that are not directly referenced in any of your markdown files or theme components - for example, favicons and PWA icons. In such cases, you can put them inside this directory and they will be copied to the root of the generated directory.

See the documentation for more information:

https://v1.vuepress.vuejs.org/guide/assets.html#public-files